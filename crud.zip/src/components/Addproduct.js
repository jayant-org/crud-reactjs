const Addproduct = () => {
    return (
        <div className="container mt-5">
            <h2>Add Product</h2>
            <form className="row">
                <div className="col-5">
                    <label>Product Name</label>
                    <input type="text" className="form-control" placeholder="Name"/>
                </div>
                <div className="col-5">
                    <label>Product Name</label>
                    <input type="text" className="form-control" placeholder="Name"/>
                </div>
                <div className="col-5">
                    <label>Product Name</label>
                    <input type="text" className="form-control" placeholder="Name"/>
                </div>
            </form>

        </div>
        
    )
}

export default Addproduct;