import { Link } from "react-router-dom";

const Products = () => {
    return (
        <div className="container mt-5">
            <h2>Product List</h2>
            <div className="col">
                <Link to='/add-product' className="btn btn-primary">Add Product</Link>
            </div>
            <table className="table table-stripped">
                <thead>
                    <tr>
                        <th>Sr.</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>


    )
}

export default Products;