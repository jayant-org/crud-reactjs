import { useEffect, useState } from 'react';
import { Modal, ModalHeader, ModalFooter, ModalBody, Button } from 'reactstrap';
import { v4 as uuidv4 } from 'uuid';

const Users = () => {
    const storageKey = "userRecords";
    const [addModel, setAddModel] = useState(false);
    const [deleteModal, setDeleteModel] = useState(false);
    const [editModal, setEditModel] = useState(false);
    const [input, setInput] = useState({firstname : '', lastname : '', email : '', phone : '', city : ''});
    const [error, setError] = useState({});
    const [UserData, setUserData] = useState([])
    const [userID, setUserID] = useState();
    const [userDetails, setUserDetails] = useState({});
    const [inputSearch, setInputSearch] = useState({s_firstname : '', s_lastname : '', s_email : '' });

    const Addtoggle = () => {
        setAddModel(!addModel)
    }

    const Deletetoggle = (e, uuid) => {
        setDeleteModel(!deleteModal)
        if (uuid !== undefined) {
            setUserID(uuid)
        }
    }

    const Edittoggle = (e, uuid) => {
        console.log("uid", uuid)
        if (uuid !== undefined) {
            setUserID(uuid);
            const userDetail = UserData.filter((user) => user.uuid === uuid);
            setUserDetails(userDetail[0]);
        }
        setEditModel(!editModal)
    }


    const deleteHandle = () => {
        const data = UserData.filter((u) => u.uuid !== userID);
        localStorage.setItem(storageKey, JSON.stringify(data));
        setDeleteModel(!deleteModal);
    }

    const updateUser = () => {
        const Error = Validation(userDetails);
        if (Object.keys(Error).length === 0) {
            const updateData = UserData.map((user) => {
                if (user.uuid === userID) {
                    return { ...user, ...userDetails }
                }
                return user;
            })

            const stringifyed = JSON.stringify(updateData);
            localStorage.setItem(storageKey, stringifyed);
            setEditModel(!editModal)
        }
    }


    const handleInput = (e) => {
        setInput({
            ...input,
            [e.target.name]: e.target.value
        })
    }

    const handleUser = (e) => {
        setUserDetails({
            ...userDetails,
            [e.target.name]: e.target.value
        })
    }

    const handleSearch = (e) => {
        setInputSearch({
            ...inputSearch,
            [e.target.name] : e.target.value
        })
    }
    const handleFilter = () => {
        if(inputSearch.s_firstname !== '' || inputSearch.s_lastname !== '' || inputSearch.s_email !== ''){
            const searchData = UserData.filter( (item) => {
                return (item.firstname === inputSearch.s_firstname ||
                item.lastname === inputSearch.s_lastname ||
                item.email === inputSearch.s_email )

            })
            setUserData(searchData);
        }else{
            fetchData();
        }
    }

    const handleReset = () => {
        fetchData();
        setInputSearch({s_firstname:'', s_lastname:'', s_email:''})
    }

    const saveUser = () => {
        const Error = Validation(input);
        if (Object.keys(Error).length === 0) {
            const oldData = localStorage.getItem(storageKey);
            const previousData = oldData ? JSON.parse(oldData) : [];
            input.uuid = uuidv4();
            const updateData = [...previousData, { ...input }];
            const stringifydata = JSON.stringify(updateData);
            localStorage.setItem(storageKey, stringifydata);

            setAddModel(!addModel);
            setInput({});
        }
    }

    const Validation = (inputdata) => {

        let Error = {};
        if (!inputdata.firstname) {
            Error['firstname'] = 'Required'
        }
        if (!inputdata.lastname) {
            Error['lastname'] = 'Required'
        }
        if (!inputdata.email) {
            Error['email'] = 'Required'
        }
        if (!inputdata.phone) {
            Error['phone'] = 'Required'
        }
        if (!inputdata.city) {
            Error['city'] = 'Required'
        }

        setError(Error);
        return Error;
    }

    useEffect(() => {
        fetchData();
    }, [addModel, deleteModal, editModal])

    const fetchData = () =>{
        let Users = localStorage.getItem(storageKey);
        Users = Users ? JSON.parse(Users) : []
        setUserData(Users);
    }

    return (
        <div className="container mt-5">

            <h3>Users List</h3>
            <div className="row">
                <div className="col col-2">
                    <Button color='primary' onClick={Addtoggle}>Add User</Button>
                </div>
                <div className="col col-lg-2">
                    <input type="text" placeholder='First Name' name='s_firstname' value={inputSearch.s_firstname} className='form-control' onChange={handleSearch} />
                </div>
                <div className="col col-lg-2">
                    <input type="text" placeholder='Last Name' name='s_lastname' value={inputSearch.s_lastname} className='form-control' onChange={handleSearch} />
                </div>
                <div className="col col-lg-2">
                    <input type="text" placeholder='Email' name='s_email' value={inputSearch.s_email} className='form-control' onChange={handleSearch}  />
                </div>
                <div className="col col-lg-3">
                    <Button color='info' onClick={handleFilter}>Search</Button>
                    <Button color='secondary my-50' onClick={handleReset}>Reset</Button>
                </div>
            </div>
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>Sr.</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>City</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        UserData.map((item, index) => (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{item.firstname}</td>
                                <td>{item.lastname}</td>
                                <td>{item.email}</td>
                                <td>{item.phone}</td>
                                <td>{item.city}</td>
                                <td>
                                    <Button color='primary' className='mx-2' onClick={(e) => Edittoggle(e, item.uuid)}>Edit</Button>
                                    <Button color='danger' onClick={(e) => Deletetoggle(e, item.uuid)}>Delete</Button>
                                </td>
                            </tr>
                        ))
                    }
                </tbody>
            </table>

            {/* model add user */}
            <Modal toggle={Addtoggle} isOpen={addModel}>
                <ModalHeader toggle={Addtoggle}>Add New User</ModalHeader>
                <ModalBody>
                    <form className='row'>
                        <div className='col-6'>
                            <label>First Name<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' value={input.firstname} name='firstname' onChange={handleInput} />
                            <h6 className='fs-6 text-danger'>{error.firstname}</h6>
                        </div>
                        <div className='col-6'>
                            <label>Last Name<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='lastname' value={input.lastname} onChange={handleInput} />
                            <h6 className='fs-6 text-danger'>{error.lastname}</h6>
                        </div>
                        <div className='col-6'>
                            <label>Email<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='email' value={input.email} onChange={handleInput} />
                            <h6 className='fs-6 text-danger'>{error.email}</h6>
                        </div>
                        <div className='col-6'>
                            <label>Phone<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='phone' value={input.phone} onChange={handleInput} />
                            <h6 className='fs-6 text-danger'>{error.phone}</h6>
                        </div>
                        <div className='col-6'>
                            <label>City<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='city' value={input.city} onChange={handleInput} />
                            <h6 className='fs-6 text-danger'>{error.city}</h6>
                        </div>

                    </form>
                </ModalBody>
                <ModalFooter>
                    <Button color='primary' onClick={saveUser}>Save</Button>
                    <Button color='secondary' onClick={Addtoggle}>Cancel</Button>
                </ModalFooter>
            </Modal>
            {/* delete Models */}
            <Modal isOpen={deleteModal} toggle={Deletetoggle}>
                <ModalHeader toggle={Deletetoggle}>Delete User</ModalHeader>
                <ModalBody>
                    Are you sure to delete?
                </ModalBody>
                <ModalFooter>
                    <Button color='primary' onClick={deleteHandle}>Delete</Button>
                    <Button color='secondary' onClick={Deletetoggle}>Cancel</Button>
                </ModalFooter>
            </Modal>

            {/* edit Model */}
            {/* model add user */}
            <Modal toggle={Edittoggle} isOpen={editModal}>
                <ModalHeader toggle={Edittoggle}>Update User</ModalHeader>
                <ModalBody>
                    <form className='row'>
                        <div className='col-6'>
                            <label>First Name<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' value={userDetails.firstname} name='firstname' onChange={handleUser} />
                            <h6 className='fs-6 text-danger'>{error.firstname}</h6>
                        </div>
                        <div className='col-6'>
                            <label>Last Name<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='lastname' value={userDetails.lastname} onChange={handleUser} />
                            <h6 className='fs-6 text-danger'>{error.lastname}</h6>
                        </div>
                        <div className='col-6'>
                            <label>Email<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='email' value={userDetails.email} onChange={handleUser} />
                            <h6 className='fs-6 text-danger'>{error.email}</h6>
                        </div>
                        <div className='col-6'>
                            <label>Phone<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='phone' value={userDetails.phone} onChange={handleUser} />
                            <h6 className='fs-6 text-danger'>{error.phone}</h6>
                        </div>
                        <div className='col-6'>
                            <label>City<em className='text-danger'>*</em></label>
                            <input type='text' className='form-control' name='city' value={userDetails.city} onChange={handleUser} />
                            <h6 className='fs-6 text-danger'>{error.city}</h6>
                        </div>

                    </form>
                </ModalBody>
                <ModalFooter>
                    <Button color='primary' onClick={updateUser}>Save</Button>
                    <Button color='secondary' onClick={Edittoggle}>Cancel</Button>
                </ModalFooter>
            </Modal>



        </div>
    )
}

export default Users;